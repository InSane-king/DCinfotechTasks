const jwt = require('jsonwebtoken');
const User = require('./models/User');

// Register Route
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  const user = new User({ username, password });
  await user.save();
  res.status(201).json(user);
});

// Login Route
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });

  if (!user || !(await user.matchPassword(password))) {
    return res.status(400).send('Invalid credentials');
  }

  const token = jwt.sign({ id: user._id }, 'secret-key', { expiresIn: '1h' });
  res.json({ token });
});

// Protect Routes (e.g., To-Do API)
const protect = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1];
  if (!token) return res.status(401).send('No token, authorization denied');

  jwt.verify(token, 'secret-key', (err, decoded) => {
    if (err) return res.status(403).send('Invalid token');
    req.user = decoded;
    next();
  });
};
// app.post('/api/todos', protect, async (req, res) => {
//     // Add new todo
//   });
  
//   app.get('/api/todos', protect, async (req, res) => {
//     // Get todos
//   });
  