const mongoose = require('mongoose');

mongoose.connect('your-mongodb-connection-string', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection
  .once('open', () => console.log('Connected to MongoDB'))
  .on('error', (error) => console.log(error));
