// Image Gallery Functionality
const thumbnails = document.querySelectorAll('.thumbnail');
const modal = document.getElementById('modal');
const modalImage = document.getElementById('modalImage');
const caption = document.getElementById('caption');
const closeModal = document.querySelector('.close');

thumbnails.forEach((thumbnail) => {
  thumbnail.addEventListener('click', () => {
    modal.style.display = 'block';
    modalImage.src = thumbnail.getAttribute('data-full');
    caption.innerHTML = thumbnail.alt;
  });
});

closeModal.addEventListener('click', () => {
  modal.style.display = 'none';
});

// Contact Form Validation
const contactForm = document.getElementById('contactForm');
const formStatus = document.getElementById('formStatus');

contactForm.addEventListener('submit', (e) => {
  e.preventDefault(); // Prevent form from submitting
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();

  if (!name || !email || !message) {
    formStatus.textContent = 'Please fill out all fields!';
    formStatus.style.color = 'red';
    return;
  }

  if (!/\S+@\S+\.\S+/.test(email)) {
    formStatus.textContent = 'Please enter a valid email address!';
    formStatus.style.color = 'red';
    return;
  }

  formStatus.textContent = 'Thank you! Your message has been sent.';
  formStatus.style.color = 'green';
  contactForm.reset();
});
