const express = require('express');
const Todo = require('../models/Todo');
const jwt = require('jsonwebtoken');
const router = express.Router();

// Middleware to protect routes
const protect = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1];
  if (!token) return res.status(401).send('No token, authorization denied');

  jwt.verify(token, 'secret-key', (err, decoded) => {
    if (err) return res.status(403).send('Invalid token');
    req.user = decoded;
    next();
  });
};

// Create new todo
router.post('/', protect, async (req, res) => {
  const { text } = req.body;
  const newTodo = new Todo({ text });
  await newTodo.save();
  res.status(201).json(newTodo);
});

// Get all todos
router.get('/', protect, async (req, res) => {
  const todos = await Todo.find();
  res.json(todos);
});

// Delete todo by id
router.delete('/:id', protect, async (req, res) => {
  await Todo.findByIdAndDelete(req.params.id);
  res.status(200).send('Todo deleted');
});

module.exports = router;
