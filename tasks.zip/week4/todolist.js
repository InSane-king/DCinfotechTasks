import React from "react";
import "./TodoList.css";

function TodoList({ todos, completeTodo, deleteTodo }) {
  return (
    <div>
      {todos.map((todo) => (
        <div
          key={todo.id}
          className={`todo ${todo.isComplete ? "complete" : ""}`}
        >
          <div
            className="todo-text"
            onClick={() => completeTodo(todo.id)}
          >
            {todo.text}
          </div>
          <button
            className="delete-button"
            onClick={() => deleteTodo(todo.id)}
          >
            X
          </button>
        </div>
      ))}
    </div>
  );
}

export default TodoList;
